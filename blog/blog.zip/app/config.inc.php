<?php
//info de la base de datos
define('nombre_servidor','localhost');
define('NOMBRE_USUARIO','root');
define('PASSWORD','');
define('dbname','blog');

//rutas de la web
define("SERVIDOR", "http://localhost/blog");
define("RUTA_REGISTRO",          SERVIDOR."/registro.php");
define("RUTA_REGISTRO_CORRECTO", SERVIDOR."/registro-correcto.php");
define("RUTA_LOGIN", SERVIDOR."/login.php");
define("RUTA_LOGOUT", SERVIDOR."/logout.php")

?>




