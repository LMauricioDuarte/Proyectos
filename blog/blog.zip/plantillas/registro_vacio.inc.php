<div class="form-group"
     <label>Nombre de Usuario</label>
    <input type="text" class="form-control" name="nombre" placeholder="Usuario">
</div>
<div class="form-group"
     <label>Email</label>
    <input type="email" class="form-control" name="email" placeholder="usuario@mail.com">
</div>
<div class="form-group"
     <label>Contraseña</label>
    <input type="password" class="form-control" name="clave1">
</div>
<div class="form-group"
     <label>Repite la Contraseña</label>
    <input type="password" class="form-control" name ="clave2">
</div>
<br>
<button type="reset" class="btn btn-default btn-primary">Limpiar Datos</button>
<button type="submit" class="btn btn-default btn-primary" name="enviar">Enviar Datos</button>
