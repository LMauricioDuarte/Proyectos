<script src="js/jquery.min.js" type="text/javascript">
</script> <!-- libreria hace que funcione todo en cualquier compu o celular, detecta en que dispositivo esta funcioando javascript -->
<script src="js/bootstrap.min.js" type="text/javascript"></script>

</body>
</html>
